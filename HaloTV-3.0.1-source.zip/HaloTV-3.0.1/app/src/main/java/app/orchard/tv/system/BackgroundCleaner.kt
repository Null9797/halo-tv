package app.orchard.tv.system

import android.app.ActivityManager
import android.content.Context
import android.content.Intent
import android.content.pm.ApplicationInfo
import android.media.AudioManager
import android.os.Build
import android.net.ConnectivityManager
import android.net.NetworkCapabilities

/** Best-effort cleanup of cached third-party processes while Home is in front. */
object BackgroundCleaner {
    fun clean(context: Context): Int {
        if (Build.VERSION.SDK_INT >= 34) return 0
        val connectivity = context.getSystemService(Context.CONNECTIVITY_SERVICE) as? ConnectivityManager ?: return 0
        @Suppress("DEPRECATION")
        val safeNetwork = runCatching {
            connectivity.allNetworks.none { network ->
                connectivity.getNetworkCapabilities(network)?.hasTransport(NetworkCapabilities.TRANSPORT_VPN) == true
            }
        }.getOrDefault(false)
        if (!safeNetwork) return 0
        val audio = context.getSystemService(Context.AUDIO_SERVICE) as AudioManager
        if (audio.isMusicActive) return 0
        val manager = context.getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager
        val pm = context.packageManager
        @Suppress("DEPRECATION")
        val protected = runCatching { pm.queryIntentServices(Intent("android.net.VpnService"), 0).mapNotNull { it.serviceInfo?.packageName }.toSet() }.getOrElse { return 0 }
        val processes = manager.runningAppProcesses.orEmpty()
        val active = processes.filter { it.importance < ActivityManager.RunningAppProcessInfo.IMPORTANCE_CACHED }
            .flatMap { it.pkgList.orEmpty().asIterable() }.toSet()
        val cached = processes.filter { it.importance >= ActivityManager.RunningAppProcessInfo.IMPORTANCE_CACHED }
            .flatMap { it.pkgList.orEmpty().asIterable() }.toSet()
        return cached.count { name ->
            if (name == context.packageName || name in protected || name in active) return@count false
            val info = runCatching { @Suppress("DEPRECATION") pm.getApplicationInfo(name, 0) }.getOrNull() ?: return@count false
            if (info.flags and (ApplicationInfo.FLAG_SYSTEM or ApplicationInfo.FLAG_UPDATED_SYSTEM_APP) != 0) return@count false
            runCatching { manager.killBackgroundProcesses(name) }.isSuccess
        }
    }
}
