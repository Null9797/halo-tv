@file:androidx.annotation.OptIn(androidx.media3.common.util.UnstableApi::class)

package app.orchard.tv.ui.home

import android.graphics.Bitmap
import android.media.MediaMetadataRetriever
import android.view.SurfaceView
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.tween
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.setValue
import androidx.compose.runtime.snapshotFlow
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.viewinterop.AndroidView
import androidx.core.net.toUri
import androidx.media3.common.C
import androidx.media3.common.MediaItem
import androidx.media3.common.PlaybackException
import androidx.media3.common.Player
import androidx.media3.exoplayer.ExoPlayer
import app.orchard.tv.ui.components.FilmSlot
import app.orchard.tv.settings.AerialSettings
import app.orchard.tv.system.DiagLog
import app.orchard.tv.ui.theme.Motion
import app.orchard.tv.wallpaper.ScreensaverVideos
import app.orchard.tv.wallpaper.Wallpapers
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

/**
 * The owner's own videos behind Home (issues #410, #583), sent from the phone page as for the video
 * screensaver: silent, filling the screen, one after another or just the one chosen on a loop (#762). They move when the aerial wallpaper
 * would (LiveWallpaper): on a still shelf, or all the time when set to keep moving. A key that
 * stops them leaves the frame they stopped on as the wallpaper's picture, read off the video plane
 * where the TV allows it and otherwise decoded from the file, which is on the TV.
 */
@Composable
fun VideoWallpaper(
    moving: Boolean,
    /** Keep the paused video visible behind panels instead of swapping to an unrelated image. */
    standIn: Boolean,
    /** False once the screensaver is up or Home is behind an app: the decoder goes at once. */
    keep: Boolean,
    lastInputAt: Long,
    cover: Animatable<Float, *>,
) {
    val context = LocalContext.current
    var player by remember { mutableStateOf<ExoPlayer?>(null) }
    var surface by remember { mutableStateOf<SurfaceView?>(null) }
    var showing by remember { mutableStateOf(false) }
    var idle by remember { mutableStateOf(false) }
    LaunchedEffect(lastInputAt, moving) {
        idle = false
        if (!moving) return@LaunchedEffect
        delay(START_AFTER_MS)
        idle = true
    }
    val play = moving && (idle || AerialSettings.wallpaperAlwaysMoves)
    val keepNow by rememberUpdatedState(keep)
    val standInNow by rememberUpdatedState(standIn)
    val scope = rememberCoroutineScope()

    fun release() {
        player?.release()
        player = null
        showing = false
        Wallpapers.dropFilmFrost()
    }

    suspend fun open(): ExoPlayer? {
        val films = withContext(Dispatchers.IO) { Wallpapers.videoFilms() }
        if (films.isEmpty()) return null
        // Where the picture on screen came from, so moving again does not cut to another place.
        val spot = Wallpapers.videoSpot()
        val first = films.indexOfFirst { it.id == spot?.first }
        var rendered = false
        return ExoPlayer.Builder(context).build().apply {
            volume = if (AerialSettings.videoWallpaperMuted) 0f else 1f
            repeatMode = Player.REPEAT_MODE_ALL
            // Filled to the edges whatever its shape: a wallpaper has no bars.
            videoScalingMode = if (AerialSettings.videoWallpaperFit) C.VIDEO_SCALING_MODE_SCALE_TO_FIT else C.VIDEO_SCALING_MODE_SCALE_TO_FIT_WITH_CROPPING
            // Home is drawn over it: the display keeps its rate (see LiveWallpaper).
            videoChangeFrameRateStrategy = C.VIDEO_CHANGE_FRAME_RATE_STRATEGY_OFF
            addListener(object : Player.Listener {
                override fun onRenderedFirstFrame() {
                    rendered = true
                    showing = isPlaying
                }

                override fun onIsPlayingChanged(isPlaying: Boolean) {
                    showing = isPlaying && rendered
                }

                // Playing them in turn where the glass cannot be read off the video: the picture under
                // it stayed the first film's, and so did the glass of the plate and Control Center
                // through every film after it (TCL MT9655, issue #1158). Each film's poster now.
                override fun onMediaItemTransition(mediaItem: MediaItem?, reason: Int) {
                    val id = mediaItem?.mediaId ?: return
                    if (copyGlassPossible || reason == Player.MEDIA_ITEM_TRANSITION_REASON_PLAYLIST_CHANGED) return
                    scope.launch {
                        val poster = withContext(Dispatchers.IO) { Wallpapers.videoPoster(id, Wallpapers.screenW, Wallpapers.screenH) } ?: return@launch
                        if (!keepNow || player?.currentMediaItem?.mediaId != id || !Wallpapers.isVideo()) return@launch
                        val applied = Wallpapers.useLiveFrame(poster, id, 0L) { keepNow && player?.currentMediaItem?.mediaId == id }
                        // And the plate's glass while it moves, made once from the first film's picture
                        // (sampleGlass): it kept that film's colours until Control Center was opened
                        // (issue #1158 on 1.81, the reporter on MT9655).
                        if (applied) Wallpapers.useStillFilmFrost()
                    }
                }

                override fun onPlayerError(error: PlaybackException) {
                    DiagLog.i("video wallpaper failed (${error.errorCodeName})")
                    // Behind an app or a screensaver the decoder is theirs: no retry.
                    if (!keepNow) return
                    // One film this TV cannot decode; the others may still play.
                    if (mediaItemCount > 1) {
                        removeMediaItem(currentMediaItemIndex)
                        prepare()
                    }
                }
            })
            setMediaItems(
                films.map { MediaItem.Builder().setUri(it.file.toUri()).setMediaId(it.id).build() },
                first.coerceAtLeast(0),
                if (first >= 0) spot?.second ?: 0L else 0L,
            )
            surface?.let { setVideoSurfaceView(it) }
            prepare()
        }
    }

    LaunchedEffect(player, AerialSettings.videoWallpaperMuted, AerialSettings.videoWallpaperFit) {
        player?.volume = if (AerialSettings.videoWallpaperMuted) 0f else 1f
        player?.videoScalingMode = if (AerialSettings.videoWallpaperFit) C.VIDEO_SCALING_MODE_SCALE_TO_FIT else C.VIDEO_SCALING_MODE_SCALE_TO_FIT_WITH_CROPPING
    }

    // The plate's glass over the moving video, where PixelCopy reads it. Not from the file: an
    // owner's video may be 4K HEVC, and a second decoder beside the player's may not be there.
    LaunchedEffect(play, showing) {
        if (!play || !showing) return@LaunchedEffect
        // Once per playback start for an older upload without a poster. This reads the existing
        // player surface, not the file, and never opens another decoder on TCL televisions.
        val id = player?.currentMediaItem?.mediaId
        if (id != null && !withContext(Dispatchers.IO) { Wallpapers.hasVideoPoster(id) }) {
            delay(1000)
            if (player?.currentMediaItem?.mediaId == id) {
                surface?.let { copyVideoPoster(it) }?.let { Wallpapers.keepPlayingVideoPoster(id, it) }
            }
        }
        sampleGlass({ player }, canTake = { copyGlassPossible }) {
            val frame = surface?.let { copyGlass(it) }
            val id = player?.currentMediaItem?.mediaId
            if (frame != null && id != null) Wallpapers.keepPlayingVideoPoster(id, frame)
            frame
        }
    }

    // Let go as Aerial stops, not at the next frame, which does not come then (rememberStops).
    val stops = rememberStops {
        if (player == null) return@rememberStops false
        DiagLog.i("video wallpaper lets go as Aerial stops")
        release()
        scope.launch { cover.snapTo(0f) }
        true
    }

    LaunchedEffect(play, stops, keep) {
        // Losing Home or entering a screensaver must cancel an in-flight frame capture and free
        // the decoder even if playback was already paused. Several TVs have only one video path.
        if (!keep) {
            player?.pause()
            cover.snapTo(0f)
            release()
            return@LaunchedEffect
        }
        if (play) {
            val p = player ?: open()?.also { player = it } ?: return@LaunchedEffect
            DiagLog.i("video wallpaper starts (${p.currentMediaItem?.mediaId} at ${p.currentPosition} ms, idle $idle)")
            Wallpapers.dropFilmFrost()
            if (p.playbackState == Player.STATE_IDLE) p.prepare()
            p.playWhenReady = true
            snapshotFlow { showing }.first { it }
            cover.animateTo(1f, tween(250, easing = Motion.EaseOut))
        } else {
            val p = player ?: return@LaunchedEffect
            if (!keepNow) {
                cover.snapTo(0f)
                release()
                return@LaunchedEffect
            }
            p.pause()
            DiagLog.i("video wallpaper stops at ${p.currentPosition} ms")
            if (cover.value > 0f) {
                // The video surface already contains the exact frame. Keep it under an open
                // control center or wallpaper sheet, including TVs that cannot copy video.
                if (standInNow && keepNow) {
                    snapshotFlow { standInNow && keepNow }.first { !it }
                    if (!keepNow) return@LaunchedEffect
                }
                val film = p.currentMediaItem?.mediaId
                val at = p.currentPosition
                val w = surface?.width?.takeIf { it > 0 } ?: Wallpapers.screenW
                val h = surface?.height?.takeIf { it > 0 } ?: Wallpapers.screenH
                // Neither on TCL MT9655 at times: then the film's own poster, so the picture and its
                // glass are at least the film that played, not the one shown before (issue #1158).
                // Not from the file where reading frames jams the media server (TCL's extractor): on
                // TCL MT5879 every stop read one, and the decoders failed to start or failed
                // mid-film after it, each time a stop came before (issue #1188, Aerial's own log).
                val frame = surface?.let { copyFrame(it) }
                    ?: film?.let { id ->
                        withContext(Dispatchers.IO) {
                            (if (fileFramesJam(context)) null else fileFrame(context, id, at, w, h)) ?: Wallpapers.videoPoster(id, w, h)
                        }
                    }
                if (frame != null && film != null) Wallpapers.useLiveFrame(frame, film, at)
                cover.animateTo(0f, tween(if (frame != null) 320 else 600, easing = Motion.EaseOut))
            }
            delay(KEEP_STOPPED_MS)
            release()
        }
    }
    LaunchedEffect(keep) {
        if (!keep && !play && player != null && cover.value == 0f) release()
    }
    DisposableEffect(Unit) { onDispose { release() } }

    AndroidView(
        modifier = Modifier.fillMaxSize(),
        factory = { ctx -> FilmSlot(ctx).also { surface = it.surface; player?.setVideoSurfaceView(it.surface) } },
        onRelease = { player?.clearVideoSurfaceView(it.surface); surface = null },
    )
}

/** Frame [atMs] of the owner's video [id], screen-sized and drawable on, or null. */
private fun fileFrame(context: android.content.Context, id: String, atMs: Long, w: Int, h: Int): Bitmap? {
    val film = ScreensaverVideos.all(context).firstOrNull { it.id == id } ?: return null
    val mmr = MediaMetadataRetriever()
    return try {
        mmr.setDataSource(film.file.path)
        val frame = mmr.getFrameAtTime(atMs * 1000, MediaMetadataRetriever.OPTION_CLOSEST) ?: return null
        app.orchard.tv.wallpaper.Images.cover(frame, w, h).let {
            if (it.isMutable && it.config == Bitmap.Config.ARGB_8888) it else it.copy(Bitmap.Config.ARGB_8888, true)
        }
    } catch (e: Exception) {
        DiagLog.i("video wallpaper frame not decoded: ${e.javaClass.simpleName}")
        null
    } finally {
        runCatching { mmr.release() }
    }
}
