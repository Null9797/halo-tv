# HaloTV 3.1 independent identity migration

Baseline: halo-31-preview, full code 192 / lite 48.
Deliver bridge (old identity) and independent (new identity), each Guard/Standard/Lite.
New application IDs: app.halotv.launcher and app.halotv.launcher.lite.
Keep internal namespaces stable; runtime identifiers, providers/accounts/installer targets and update channels must follow applicationId.
Bridge trusts only old identity + old certificate OR independent identity + pinned new certificate + same edition.
Independent updates accept only independent identity and new certificate.
Bridge provides explicit online migration and validated phone uploads; settings/material transfer is opt-in and authenticated; never copy system grants.
Do not touch user TV, do not uninstall anything.
Publish announcement only targeting bridge full/lite build codes after independent packages have a usable download destination.
All signing secrets excluded from source archives and public files.
