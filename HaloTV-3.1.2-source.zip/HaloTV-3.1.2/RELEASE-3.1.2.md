# HaloTV 3.1.2

本次提供 Standard、Guard、Lite 三个独立版安装包，继续使用 HaloTV 独立包名与专属签名。发布文件名为 `HaloTV-3.1.2-standard.apk`、`HaloTV-3.1.2-guard.apk`、`HaloTV-3.1.2-lite.apk`。

## 重点：桌面守护稳定性与诊断

以下守护改动适用于 Android 5.0+ 的 Standard / Guard。Lite 同步发行 3.1.2，保留其轻量实现，不包含正式版 HomeGuardService，也不宣称获得同样的接管能力。

- **减少重复解绑。** 新登记守护后给予 5 秒绑定宽限，重复重绑至少间隔 15 秒，避免开机、通知恢复和应用恢复入口互相打断系统正在建立的绑定。
- **补齐迁移交接防线。** 对通知恢复、同步恢复、开机回调、锁屏补拉、更新返回和旧服务异步回调重新检查身份与交接状态，减少旧实例或已让出守护的包再次抢前台。
- **解锁前状态保护。** 将交接标记镜像到设备保护区；Direct Boot 阶段也能识别交接。已有旧版程序不会被新包改写，仍需用户确认后关闭旧 HaloTV 守护或卸载旧 HaloTV。
- **开机恢复重试。** 在有时间预算的一次重试中等待初始绑定宽限结束；不增加无限循环或高频常驻抢前台。
- **识别与兼容。** 更新系统桌面列表时清理识别缓存；选择性参考上游针对 Android 6 VIDAA/Jamdeo Home 面板的定向处理，排除对话框，保留用户主动进入系统界面的行为。并修正 Android 5 分支临时重扫组件还原时对无关授权的依赖。
- **状态更准确。** 守护设置页区分“服务已登记”“无障碍总开关”“实际运行”“安全设置权限”“已知受限设置阻止”及“其他守护并存”；无法读取的状态不会被显示为已授权。
- **写后验证。** 恢复操作读取系统保存结果并保留其他无障碍服务，不把命令返回成功直接当作服务实际绑定成功。
- **独立版专用工具。** 新增 `tools/halo-guard.sh` 与说明，默认只读诊断；用户主动加 `--repair` 才按需配置独立包。不会禁用系统桌面、卸载其他应用、修改网络或持久开启 ADB。修复模式仅支持可确认的 Android 主用户 0。

## 安装、升级与迁移

- Standard / Guard：`app.halotv.launcher`，versionCode **197**，Android 5.0+。
- Lite：`app.halotv.launcher.lite`，versionCode **52**，Android 4.0+。
- 三个安装包的 versionName 均为 **3.1.2**。内部号高于此前独立版及守护测试包，可用同类型、同签名包覆盖更新。
- 独立版 3.1 / 3.1.1 用户在软件更新页检查更新，官网下载优先，GitHub 备用；下载后仍需按电视系统要求确认安装。
- 旧包名用户仍先安装 **3.1 对应过渡版**，再安装独立版、导入资料、重新配置默认桌面/屏保/守护权限。旧 `stable.json` 保持指向过渡版，独立版使用独立更新清单；新包名不能原地覆盖旧包。
- 独立版可以与 Aerial 同时安装，但不建议同时启用两套桌面守护。旧 `app.orchard.tv` 可能是 Aerial，也可能是旧 HaloTV，不能仅凭包名自动卸载或停用。
- 安装与卸载命令已更新为独立包名，保留原 Kotlin 类命名空间。独立版组件是 `app.halotv.launcher/app.orchard.tv.guard.HomeGuardService`，不是 `app.halotv.launcher/.guard.HomeGuardService`。

## 迁移提醒公告

配套公告提醒支持远程公告且能联网的旧客户端迁移到独立版：安装后重新开启守护，确认可用后卸载旧 HaloTV。没有远程公告功能、被用户关闭或无法联网的客户端，无法保证收到弹窗；公告不会静默安装或卸载应用。

## 验证范围与限制

守护修复测试阶段 Standard / Guard 各 410 项自动测试、诊断工具 24 项离线回归通过，Release 构建与 Lint 错误检查通过。正式包的三版测试、包名、版本、签名、ZIP 和对齐校验以本次发布校验记录为准。Lint 仍保留既有风格与兼容性提示，不等于没有任何警告。

本次未取得反馈用户故障电视的实机日志，也没有覆盖所有电视的 Home、冷启动和次日恢复验证。厂商可限制第三方默认桌面、无障碍、通知监听和自启动；不能保证每台电视零闪烁或守护永久有效。代码优化不会替代系统授权。遇到问题请提供品牌型号、Android 版本、Standard/Guard/Lite、守护实际状态及按 Home/开机分别的表现。

## 开源与内容来源

HaloTV 基于 [Aerial](https://github.com/pengchujin/aerial-tv) 二次开发，由 Null_ 整理发布，非上游官方版本。感谢原作者及贡献者，保留版权、MIT 许可与来源说明。本次只选择性参考相关上游守护改动，不宣称完整合并最新上游版本。

Bing 壁纸归档由 [YanGN](https://github.com/ygnstudio/bing_wallpaper_archive) 提供；在线视频目录参考 [Aerial Views](https://github.com/theothernt/AerialViews)，视频来自 Apple，素材版权归各权利人。代码许可不代替素材授权。

[官网](https://halo-tv.pages.dev/) · [仓库](https://github.com/Null9797/halo-tv) · [网盘](https://pan.quark.cn/s/a14e3ab2dd41)（网盘内容以实际页面为准）
