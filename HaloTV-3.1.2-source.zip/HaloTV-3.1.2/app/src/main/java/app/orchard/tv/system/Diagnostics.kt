package app.orchard.tv.system

import android.Manifest
import android.app.ActivityManager
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.media.tv.TvInputInfo
import android.media.tv.TvInputManager
import android.os.Build
import android.provider.Settings
import android.util.DisplayMetrics
import android.view.WindowManager
import androidx.core.app.NotificationManagerCompat
import androidx.core.content.ContextCompat
import androidx.core.content.getSystemService
import app.orchard.tv.BuildConfig
import app.orchard.tv.guard.GuardSetup
import app.orchard.tv.guard.HomeGuardService
import app.orchard.tv.settings.AerialSettings
import app.orchard.tv.update.Updates
import app.orchard.tv.wallpaper.PhoneServer
import app.orchard.tv.wallpaper.Wallpapers
import org.json.JSONArray
import org.json.JSONObject

/**
 * What a maintainer without the reporter's TV needs to adapt Aerial to it, as Markdown to paste
 * into a GitHub issue (.github/ISSUE_TEMPLATE/device.yml). Shown on the phone page and printed by
 *   adb shell dumpsys activity app.orchard.tv/.MainActivity report
 * which tools/report.sh adds to what only a shell can read.
 *
 * Nothing personal: no account, serial number, Wi-Fi name, address, phone page token, weather city
 * or list of installed apps (only whether the packages Aerial treats specially are there). Log lines
 * have addresses masked, since a film URL or a peer can turn up in them.
 */
object Diagnostics {

    /** Packages Aerial looks for somewhere, by what they mean for it. */
    private val VENDOR_PACKAGES = listOf(
        "com.mitv.tvhome", "com.xiaomi.mitv.settings", "com.xiaomi.mitv.tvplayer", "com.xiaomi.mitv.hyper.screensaver",
        "com.tcl.settings", "com.tcl.tv", "com.tcl.MultiScreenInteraction_TV", "com.tcl.appmarket2",
        "com.hisense.vidaaassistant", "com.jamdeo.tv.vod",
        "com.tianci.tv", "com.skyworth.tv", "com.coocaa.os.launcher",
        "com.konka.tvsettings", "com.stv.deskplatform",
        "com.sony.dtv.configsettings",
        "com.google.android.tvlauncher", "com.google.android.apps.tv.launcherx", "com.android.tv.settings",
        "com.dangbeimarket",
    )

    // AerialDiag is in DiagLog already; AerialWeather names the city.
    private val LOG_TAGS = listOf("AerialGuard", "AerialUpdates", "AerialStream", "AerialWallpaper", "AerialKonkaSources", "AndroidRuntime")

    /**
     * Whether ART has compiled Aerial with its profile yet. Installed without install.sh (which runs
     * `compile -m speed`), Aerial runs interpreted until the system's background job compiles it,
     * and Home's start takes about twice as long (Xiaomi MiTV-MFTR0: tiles at 0.8 s against 0.4 s).
     */
    private fun compiled(context: Context): String {
        val profile = runCatching {
            val s = androidx.profileinstaller.ProfileVerifier.getCompilationStatusAsync().get(2, java.util.concurrent.TimeUnit.SECONDS)
            if (s.profileInstallResultCode == androidx.profileinstaller.ProfileVerifier.CompilationStatus.RESULT_CODE_ERROR_UNSUPPORTED_API_VERSION)
                "profile state not readable on this Android"
            else "with profile=${s.isCompiledWithProfile}, profile waiting=${s.hasProfileEnqueuedForCompilation()}, code=${s.profileInstallResultCode}"
        }.getOrElse { "profile state unknown (${it.javaClass.simpleName})" }
        // The compiled code beside the APK: a few hundred KB when only verified (interpreted), several
        // MB when compiled (TCL MT5879, Android 11, "speed": the profile state is not readable there).
        // The oat folder cannot be listed by the app, only opened by name.
        val oat = runCatching {
            val dir = java.io.File(java.io.File(context.applicationInfo.sourceDir).parentFile, "oat")
            listOf("arm", "arm64", "x86", "x86_64").map { java.io.File(dir, "$it/base.odex") }
                .firstOrNull { it.exists() }?.length()?.div(1024)
        }.getOrNull()
        return "$profile; odex ${oat?.let { "$it KB" } ?: "-"}"
    }

    fun report(context: Context): String = buildString {
        val pm = context.packageManager
        appendLine("### Halo TV diagnostics")
        appendLine()
        appendLine("```")
        appendLine("Halo TV     ${BuildConfig.VERSION_NAME} (${BuildConfig.VERSION_CODE}) ${BuildConfig.FLAVOR}, package ${context.packageName}, installer ${installer(context) ?: "-"}")
        appendLine("Device      ${Build.MANUFACTURER} / ${Build.BRAND} / ${Build.MODEL} (device ${Build.DEVICE}, product ${Build.PRODUCT}, hardware ${Build.HARDWARE}, board ${Build.BOARD})")
        appendLine("Android     ${Build.VERSION.RELEASE} (SDK ${Build.VERSION.SDK_INT})" + if (Build.VERSION.SDK_INT >= 23) ", patch ${Build.VERSION.SECURITY_PATCH}" else "")
        appendLine("Build       ${Build.DISPLAY}")
        appendLine("Fingerprint ${Build.FINGERPRINT}")
        listOf("ro.board.platform", "ro.product.cpu.abi", "ro.config.low_ram", "ro.build.characteristics", "persist.vt.use_home_pkg")
            .forEach { key -> prop(key)?.takeIf { it.isNotEmpty() }?.let { appendLine("  $key = $it") } }
        appendLine("Screen      ${screen(context)}")
        appendLine("Memory      ${memory(context)}")
        val network = SystemProbe.network(context)
        val validated = if (Build.VERSION.SDK_INT >= 23) runCatching {
            val cm = context.getSystemService(Context.CONNECTIVITY_SERVICE) as android.net.ConnectivityManager
            cm.getNetworkCapabilities(cm.activeNetwork)?.hasCapability(android.net.NetworkCapabilities.NET_CAPABILITY_VALIDATED)
        }.getOrNull() else null
        appendLine("Network     ${network.kind} vpn=${network.vpn} internet_validated=${validated ?: "unknown"}")
        appendLine("```")

        appendLine()
        appendLine("**Home**")
        appendLine("```")
        val homeIntent = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_HOME)
        val resolved = pm.resolveActivity(homeIntent, PackageManager.MATCH_DEFAULT_ONLY)?.activityInfo
        appendLine("Resolves to ${resolved?.let { "${it.packageName}/${it.name}" } ?: "-"}  (${SystemProbe.homeStatus(context)})")
        runCatching { pm.queryIntentActivities(homeIntent, 0) }.getOrDefault(emptyList()).forEach {
            appendLine("  candidate ${it.activityInfo.packageName}/${it.activityInfo.name} priority=${it.priority}")
        }
        HomeGuardService.stockHomes()?.forEach { (pkg, classes) -> appendLine("  guard keeps away $pkg: ${classes.joinToString()}") }
        appendLine("```")

        appendLine()
        appendLine("**Takeover**")
        appendLine("```")
        val accessibility = secure(context, Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES)
        val guardHealth = app.orchard.tv.guard.GuardHealth.read(context)
        appendLine("Home Guard  configured=${guardHealth.configured} enabled=${guardHealth.enabled} running=${guardHealth.running}")
        appendLine("  recovery secure=${guardHealth.secureSettingsGranted} restricted_blocked=${guardHealth.restrictedSettingsBlocked ?: "unknown"} other_guards=${guardHealth.otherGuardPackages.joinToString().ifEmpty { "none" }}")
        appendLine("  accessibility services: ${accessibility ?: "-"}")
        appendLine("Revival     notification listener allowed=${NotificationManagerCompat.getEnabledListenerPackages(context).contains(context.packageName)}, revivals in 10 min=${GuardSetup.revivedOften(context).let { if (it) "3 or more" else "fewer than 3" }}")
        appendLine("Grants      WRITE_SECURE_SETTINGS=${granted(context, Manifest.permission.WRITE_SECURE_SETTINGS)}" +
            " overlay=${Build.VERSION.SDK_INT < 23 || Settings.canDrawOverlays(context)}" +
            " WRITE_SETTINGS=${Build.VERSION.SDK_INT < 23 || Settings.System.canWrite(context)}" +
            " install=${Build.VERSION.SDK_INT < 26 || pm.canRequestPackageInstalls()}" +
            " location=${granted(context, Manifest.permission.ACCESS_FINE_LOCATION)}" +
            " usage=${HomeGuardService.usageStatsAllowed(context)}" + restrictedSettings(context))
        appendLine("ADB         adb_enabled=${global(context, Settings.Global.ADB_ENABLED)} keep_adb=${GuardSetup.keepAdb(context)} guard_off_in_standby=${GuardSetup.offInStandby(context)}")
        appendLine("Screensaver enabled=${secure(context, "screensaver_enabled")} components=${secure(context, "screensaver_components")} Aerial's=${Wallpapers.screensaver}")
        appendLine("Sounds      sound_effects_enabled=${system(context, Settings.System.SOUND_EFFECTS_ENABLED)}")
        appendLine("Effects     ${AerialSettings.effects.key}, lite=${AerialSettings.lite}; ${DeviceClass.describe(context)}")
        appendLine("Compiled    ${compiled(context)}")
        appendLine("Frames      ${FrameStats.summary()}")
        appendLine("Settings    focus=${AerialSettings.focusStyle.key} one_row=${AerialSettings.oneRowHome} columns=${AerialSettings.homeColumns} peek=${AerialSettings.peekNextRow} names=${AerialSettings.showAllNames} plate=${AerialSettings.homePlate} boot_source=${AerialSettings.bootSource != null} boot_app=${AerialSettings.bootApp}")
        appendLine("            clock_hours=${AerialSettings.clockHours.key} home_locked=${AerialSettings.homeLocked} photo_minutes=${AerialSettings.photoMinutes} cec_switch=${AerialSettings.cecSwitch} hidden_sources=${AerialSettings.hiddenSources.size} volume_fixed=${OutputDevice.volumeFixed(context)} playback_device=${OutputDevice.isPlaybackDevice()}")
        runCatching { app.orchard.tv.wallpaper.AerialStream.usage(context) }.getOrNull()?.let { (used, limit) ->
            appendLine("Aerials     quality=${AerialSettings.aerialQuality.key} films=${app.orchard.tv.wallpaper.AerialSet.films(context).joinToString(",") { it.id.take(8) }} cache=${used / 1_048_576}/${limit / 1_048_576} MB")
        }
        appendLine("            wallpaper=${app.orchard.tv.wallpaper.Wallpapers.selectedId.substringBefore('/')} always_moves=${AerialSettings.wallpaperAlwaysMoves} quality=${AerialSettings.aerialQuality.key} weather=${AerialSettings.showWeather} saver_clock=${AerialSettings.screensaverClock}")
        runCatching { app.orchard.tv.ui.home.filmGlassReport(context) }.getOrNull()?.let { appendLine("            film glass $it") }
        appendLine("```")

        appendLine()
        appendLine("**Update check**")
        appendLine("```")
        appendLine(Updates.diagnostics())
        appendLine("```")

        appendLine()
        appendLine("**Brightness**")
        appendLine("```")
        appendLine("Aerial can set it: ${Brightness.level(context) != null}")
        appendLine("  global picture_backlight=${global(context, "picture_backlight")}  system screen_brightness=${system(context, Settings.System.SCREEN_BRIGHTNESS)} mode=${system(context, Settings.System.SCREEN_BRIGHTNESS_MODE)}")
        appendLine("```")

        appendLine()
        appendLine("**Inputs**")
        appendLine("```")
        inputs(context).forEach { appendLine(it) }
        SystemProbe.sources(context).forEach { s ->
            appendLine("  shown: ${s.label} [${s.kind}] connected=${s.connected} -> ${s.intent.component?.flattenToShortString() ?: s.intent.data}" +
                (s.xiaomiInput?.let { " input=$it" } ?: "") + " id=${s.id}")
        }
        if (Build.MANUFACTURER.equals("xiaomi", ignoreCase = true)) {
            appendLine("  hdmiN_order: " + (1..4).joinToString(" ") { "$it=${SystemProbe.xiaomiHdmiOrder(it)}" })
        }
        appendLine("```")

        // What a maintainer copies into devices.json, as it is on this TV.
        appendLine()
        appendLine("**Device profile** (${DeviceProfile.origin(context)})")
        appendLine("```json")
        appendLine(JSONObject().put("models", JSONArray(listOf(Build.MODEL))).apply {
            val profile = DeviceProfile.current(context).toJson()
            profile.keys().forEach { put(it, profile.get(it)) }
        }.toString())
        appendLine("```")

        appendLine()
        appendLine("**Packages**")
        appendLine("```")
        VENDOR_PACKAGES.forEach { pkg ->
            val info = runCatching { pm.getPackageInfo(pkg, 0) }.getOrNull() ?: return@forEach
            appendLine("$pkg ${info.versionName}" + if (info.applicationInfo?.enabled == false) " (disabled)" else "")
        }
        appendLine("```")

        appendLine()
        appendLine("<details><summary>Log</summary>")
        appendLine()
        appendLine("```")
        DiagLog.recent(150).forEach { appendLine(mask(it)) }
        appendLine("--- logcat")
        logcat().forEach { appendLine(mask(it)) }
        appendLine("```")
        appendLine()
        appendLine("</details>")
    }

    private fun inputs(context: Context): List<String> {
        val tim = context.getSystemService<TvInputManager>() ?: return listOf("no TvInputManager")
        val list = runCatching { tim.tvInputList }.getOrNull() ?: return listOf("TvInputManager refused the list")
        if (list.isEmpty()) return listOf("TvInputManager lists no inputs")
        return list.map { i ->
            val state = runCatching { tim.getInputState(i.id) }.getOrDefault(-1)
            val label = runCatching { i.loadLabel(context).toString() }.getOrDefault("?")
            "${i.id} type=${inputType(i.type)} \"$label\" state=$state" +
                (i.parentId?.let { " parent=$it" } ?: "") + if (i.isPassthroughInput) " passthrough" else ""
        }
    }

    private fun inputType(type: Int) = when (type) {
        TvInputInfo.TYPE_TUNER -> "tuner"
        TvInputInfo.TYPE_HDMI -> "hdmi"
        TvInputInfo.TYPE_COMPOSITE -> "composite"
        TvInputInfo.TYPE_COMPONENT -> "component"
        TvInputInfo.TYPE_SVIDEO -> "svideo"
        TvInputInfo.TYPE_VGA -> "vga"
        TvInputInfo.TYPE_DISPLAY_PORT -> "dp"
        TvInputInfo.TYPE_DVI -> "dvi"
        else -> type.toString()
    }

    @Suppress("DEPRECATION")
    private fun screen(context: Context): String {
        val display = context.getSystemService<WindowManager>()?.defaultDisplay ?: return "-"
        val m = DisplayMetrics().also { display.getRealMetrics(it) }
        val modes = if (Build.VERSION.SDK_INT >= 23) display.supportedModes.joinToString { "${it.physicalWidth}x${it.physicalHeight}@${"%.0f".format(it.refreshRate)}" } else "-"
        // The window can be turned where the display reads landscape: a box set to portrait (#1416).
        val win = context.resources.displayMetrics
        return "${m.widthPixels}x${m.heightPixels} ${m.densityDpi}dpi ${"%.0f".format(display.refreshRate)}Hz; modes $modes\n" +
            "            window ${win.widthPixels}x${win.heightPixels}, pictures ${Wallpapers.screenW}x${Wallpapers.screenH}"
    }

    private fun memory(context: Context): String {
        val am = context.getSystemService<ActivityManager>() ?: return "-"
        val info = ActivityManager.MemoryInfo().also { am.getMemoryInfo(it) }
        return "${info.totalMem / (1 shl 20)} MB, low-RAM device=${am.isLowRamDevice}"
    }

    @Suppress("DEPRECATION")
    private fun installer(context: Context): String? = runCatching {
        if (Build.VERSION.SDK_INT >= 30) context.packageManager.getInstallSourceInfo(context.packageName).installingPackageName
        else context.packageManager.getInstallerPackageName(context.packageName)
    }.getOrNull()

    /**
     * Android 13+: where Android says the APK came from. 3 is a local file (a USB stick, a file
     * manager, Aerial's own update before 1.63): such an app gets ACCESS_RESTRICTED_SETTINGS denied
     * and may not switch its accessibility service on, and Home Guard kept going off on two Android 14
     * TVs installed that way (issues #811 #829); install.sh allows it. An app cannot read that op
     * itself (it came out unknown on Xiaomi MiTV-MFTR0), so `adb shell appops get` tells.
     */
    private fun restrictedSettings(context: Context): String {
        if (Build.VERSION.SDK_INT < 33) return ""
        val source = runCatching { context.packageManager.getInstallSourceInfo(context.packageName).packageSource }.getOrNull()
        return " package_source=${source ?: "unknown"}"
    }

    private fun granted(context: Context, permission: String) =
        ContextCompat.checkSelfPermission(context, permission) == PackageManager.PERMISSION_GRANTED

    // Android 12 and later refuse some keys outside the public API; those show as "unreadable".
    private fun secure(context: Context, key: String) = runCatching { Settings.Secure.getString(context.contentResolver, key) }.getOrElse { "unreadable" }
    private fun global(context: Context, key: String) = runCatching { Settings.Global.getString(context.contentResolver, key) }.getOrElse { "unreadable" }
    private fun system(context: Context, key: String) = runCatching { Settings.System.getString(context.contentResolver, key) }.getOrElse { "unreadable" }

    private fun prop(key: String): String? = runCatching {
        Class.forName("android.os.SystemProperties").getMethod("get", String::class.java).invoke(null, key) as String
    }.getOrNull()

    /** This process's own lines (all an app may read), from Aerial's tags and crashes. */
    private fun logcat(): List<String> = runCatching {
        val args = listOf("logcat", "-d", "-v", "time", "-t", "400") + LOG_TAGS.map { "$it:V" } + "*:S"
        val p = ProcessBuilder(args).redirectErrorStream(true).start()
        val lines = p.inputStream.bufferedReader().use { it.readLines() }
        // logcat -d ends by itself once it has printed the buffer.
        p.destroy()
        lines.takeLast(200)
    }.getOrElse { listOf("logcat unreadable: $it") }

    private val IPV4 = Regex("""(?<![\w.])(\d{1,3}\.){3}\d{1,3}(?![\w.])""")
    private val MAC = Regex("""(?i)\b([0-9a-f]{2}:){5}[0-9a-f]{2}\b""")
    private val PHONE_PAGE = Regex(""":${PhoneServer.PORT}/\w+""")

    /** Addresses out of a log line: a film URL's host stays, a LAN or peer address does not. */
    fun mask(line: String): String = line
        .replace(PHONE_PAGE, ":${PhoneServer.PORT}/<token>")
        .replace(IPV4, "<ip>")
        .replace(MAC, "<mac>")
}
