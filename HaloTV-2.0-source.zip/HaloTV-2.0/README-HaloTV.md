# Halo TV 2.0 source

Halo TV 基于 pengchujin/aerial-tv 二次开发；上游 MIT 许可与版权声明见 LICENSE。此源码包含 Standard、Guard 与 Lite 模块。

使用 JDK 17 与 Android SDK 后，可运行 `./gradlew assembleStandardRelease assembleGuardRelease :lite:assembleRelease`。签名密钥不包含在源码中；默认本机调试签名与正式发布签名不同，不能覆盖安装由其他证书签名的版本。

Lite 支持 Android 4.0 起，尚未在 Android 4.x 实机验证。不要将个人密钥或电视调试信息提交到公开仓库。
