package app.orchard.tv.guard

import android.content.Context
import android.database.ContentObserver
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.provider.Settings
import app.orchard.tv.system.DiagLog

/**
 * A bounded boot-only observer, based on Aerial 1.97's enabled-list recovery. Unlike a permanent
 * watchdog it stops after boot, preserves explicit recovery opt-out and never grants permissions.
 * A successful first bind does not end the window: OEM boot code can erase it seconds later.
 */
internal object GuardBootWatch {
    private val handler = Handler(Looper.getMainLooper())
    private var app: Context? = null
    private var observer: ContentObserver? = null
    private var deadline = 0L
    private var repairs = 0
    private val tick = Runnable { checkNow() }
    private val finish = Runnable { stop() }
    private const val BOOT_WINDOW_MS = 5 * 60_000L
    private const val CHECK_MS = 30_000L
    private const val SETTLE_MS = 6_000L
    private const val MAX_REPAIRS = 3

    fun start(context: Context) {
        val application = context.applicationContext
        handler.post {
            if (app != null || repairs >= MAX_REPAIRS || SystemClock.elapsedRealtime() >= BOOT_WINDOW_MS || !GuardSetup.recoveryAllowed(application)) return@post
            app = application
            deadline = BOOT_WINDOW_MS
            val watch = object : ContentObserver(handler) {
                override fun onChange(selfChange: Boolean) {
                    // Debounce OEM writes and give a freshly enabled service time to bind.
                    handler.removeCallbacks(tick)
                    handler.postDelayed(tick, SETTLE_MS)
                }
            }
            try {
                application.contentResolver.registerContentObserver(Settings.Secure.getUriFor(Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES), false, watch)
                application.contentResolver.registerContentObserver(Settings.Secure.getUriFor(Settings.Secure.ACCESSIBILITY_ENABLED), false, watch)
                observer = watch
            } catch (e: Exception) {
                runCatching { application.contentResolver.unregisterContentObserver(watch) }
                DiagLog.i("guard boot watch: observer unavailable; bounded checks only")
            }
            handler.postDelayed(tick, SETTLE_MS)
            handler.postDelayed(finish, (deadline - SystemClock.elapsedRealtime()).coerceAtLeast(0L))
        }
    }

    private fun checkNow() {
        val context = app ?: return
        if (SystemClock.elapsedRealtime() >= deadline || !GuardSetup.recoveryAllowed(context)) { stop(); return }
        if (!HomeGuardService.isRunning && !GuardSetup.offInStandbyNow(context) && repairs < MAX_REPAIRS) {
            repairs++
            DiagLog.i("guard boot watch: recovery attempt $repairs/$MAX_REPAIRS")
            runCatching {
                GuardSetup.ensureEnabled(context)
                GuardSetup.rebindIfStalled(context)
            }.onFailure { DiagLog.e("guard boot watch recovery failed", it) }
        }
        if (repairs >= MAX_REPAIRS) { stop(); return }
        handler.removeCallbacks(tick)
        handler.postDelayed(tick, CHECK_MS)
    }

    fun stop() {
        handler.removeCallbacks(tick)
        handler.removeCallbacks(finish)
        val context = app
        val watch = observer
        app = null
        observer = null
        if (context != null && watch != null) runCatching { context.contentResolver.unregisterContentObserver(watch) }
    }
}
