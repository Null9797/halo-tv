package app.orchard.tv.guard

import android.content.ComponentName
import android.content.Context
import android.provider.Settings
import app.orchard.tv.migration.MigrationTransfer

/** Durable user intent, separate from the service list that OEM boot code may erase. */
object GuardRecoveryPolicy {
    private const val PREFS = "system"
    private const val KEY = "halo_guard_auto_recovery"

    @Synchronized
    fun enabled(context: Context): Boolean {
        if (!GuardSetup.isUserUnlocked(context) || MigrationTransfer.handedOff(context)) return false
        val prefs = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        if (prefs.contains(KEY)) return prefs.getBoolean(KEY, false)
        // Upgrade existing enabled guards only; a secure-settings grant alone is not user intent.
        val me = ComponentName(context, HomeGuardService::class.java)
        val configured = runCatching {
            Settings.Secure.getString(context.contentResolver, Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES)
                .orEmpty().split(':').any { ComponentName.unflattenFromString(it) == me }
        }.getOrDefault(false)
        if (configured) prefs.edit().putBoolean(KEY, true).commit()
        return configured
    }

    @Synchronized
    fun setEnabled(context: Context, enabled: Boolean) {
        if (!GuardSetup.isUserUnlocked(context) || MigrationTransfer.handedOff(context)) return
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().putBoolean(KEY, enabled).commit()
        if (!enabled) GuardBootWatch.stop()
    }
}
