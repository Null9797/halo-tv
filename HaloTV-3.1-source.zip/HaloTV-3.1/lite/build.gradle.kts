import org.jetbrains.kotlin.gradle.dsl.JvmTarget
import java.util.Properties
import java.io.File

// Aerial Lite: Home for Android 4.0-4.4 TVs, which the Compose app cannot run on (Compose needs
// Android 5.0). Plain Views, no AndroidX, so the APK stays small and Dalvik has little to load.
// Performance comes before looks here: see docs/LITE.md.
plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

val haloIndependent = project.hasProperty("haloIndependent")

android {
    namespace = "app.orchard.tv.lite"
    compileSdk = 36

    defaultConfig {
        // Its own package: the 4.x TVs never get the full app, and the two update separately.
        applicationId = if (haloIndependent) "app.halotv.launcher.lite" else "app.halotv.lite"
        // Android 4.0.
        minSdk = 14
        targetSdk = 34
        versionCode = if (haloIndependent) 50 else 49
        versionName = "3.1"
        buildConfigField("boolean", "HALO_IS_INDEPENDENT", haloIndependent.toString())
        buildConfigField("boolean", "HALO_IS_BRIDGE", (!haloIndependent).toString())
        buildConfigField("String", "HALO_CERT", "\"" + (if (haloIndependent) "ed28a19770dac5f926e7adf27224f05dd07d1a6dd54af89fc663bbcf102c41dd" else "3ba29454f5977999ccf76bd129b1087d3eea25c2f0a8370441d4fab1ccaa9198") + "\"")
        buildConfigField("String", "HALO_NEW_CERT", "\"ed28a19770dac5f926e7adf27224f05dd07d1a6dd54af89fc663bbcf102c41dd\"")
        buildConfigField("String", "HALO_TARGET_PACKAGE", "\"app.halotv.launcher.lite\"")
        buildConfigField("String", "HALO_LEGACY_PACKAGE", "\"app.halotv.lite\"")
        buildConfigField("int", "HALO_TARGET_MIN_CODE", "50")
        manifestPlaceholders["haloBridgeExported"] = (!haloIndependent).toString()
        buildConfigField("String", "HALO_EDITION", "\"lite\"")
        manifestPlaceholders["haloUpdateVariant"] = "lite"

    }

    // Signed with Halo TV’s selected distribution key (see app/build.gradle.kts and docs/HANDOFF.md).
    val signingProps = rootProject.file(if (haloIndependent) "local/independent-signing.properties" else "local/signing.properties")
    signingConfigs {
        if (signingProps.exists()) {
            val p = Properties().apply { signingProps.inputStream().use { load(it) } }
            create("aerial") {
                enableV1Signing = true
                enableV2Signing = true
                storeFile = p.getProperty("storeFile").let { if (File(it).isAbsolute) File(it) else rootProject.file("local/" + it) }
                storePassword = p.getProperty("storePassword")
                keyAlias = p.getProperty("keyAlias")
                keyPassword = p.getProperty("keyPassword")
            }
        }
    }

    if (haloIndependent) {
        sourceSets.getByName("release").res.srcDir("src/independent/res")
        sourceSets.getByName("debug").res.srcDir("src/independent/res")
    }

    buildTypes {
        release {
            isMinifyEnabled = true
            isShrinkResources = true
            proguardFiles(getDefaultProguardFile("proguard-android-optimize.txt"), "proguard-rules.pro")
            signingConfig = signingConfigs.getByName("aerial")
        }
    }

    buildFeatures { buildConfig = true }
    testOptions { unitTests.isIncludeAndroidResources = true }

    // Generated shared resources live outside the hand-authored assets.
    sourceSets["main"].assets.srcDir("lite-assets")

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    lint {
        // Old firmwares are the whole point; NewApi still guards every call above Android 4.0.
        disable += setOf("OldTargetApi", "ExpiredTargetSdkVersion")
    }
    packaging {
        resources.excludes += setOf("/META-INF/**", "kotlin/**", "DebugProbesKt.bin", "kotlin-tooling-metadata.json")
    }
}

kotlin {
    compilerOptions { jvmTarget.set(JvmTarget.JVM_17) }
}

// Shared with the full app and copied at build time: the Inter font and city list (assets),
// the glyphs' path data, the hand-made
// tile recipes and the city lookup (sources, moved into Lite's package).
val copyLiteAssets by tasks.registering(Sync::class) {
    from(rootProject.file("app/src/main/res/font/inter.ttf"))
    from(rootProject.file("app/src/main/res/font/outfit.ttf"))
    from(rootProject.file("app/src/main/assets/cities-cn.tsv"))
    from(rootProject.file("app/src/main/assets/welcome_horizon.jpg"))
    // Per-model corrections, read by DeviceProfile (MitvPanel and Brightness ask it).
    from(rootProject.file("app/src/main/assets/devices.json"))
    // The phone page, the full app's own.
    from(rootProject.file("app/src/main/assets/web")) { into("web") }
    into(layout.projectDirectory.dir("lite-assets"))
}
val sharedSources = layout.buildDirectory.dir("generated/shared")
val copySources by tasks.registering(Copy::class) {
    from(rootProject.file("app/src/main/java/app/orchard/tv/migration/MigrationIdentity.kt"))
    from(rootProject.file("app/src/main/java/app/orchard/tv/migration/MigrationTransfer.kt"))
    from(rootProject.file("app/src/main/java/app/orchard/tv/announcements/AnnouncementPolicy.kt"))
    from(rootProject.file("app/src/main/java/app/orchard/tv/announcements/AnnouncementFeed.kt"))
    from(rootProject.file("app/src/main/java/app/orchard/tv/announcements/Announcements.kt"))
    from(rootProject.file("app/src/main/java/app/orchard/tv/ui/home/QuizBank.kt"))
    from(rootProject.file("app/src/main/java/app/orchard/tv/ui/home/HaloWelcomeView.kt"))
    from(rootProject.file("app/src/main/java/app/orchard/tv/wallpaper/PhoneOnlineLibrary.kt"))
    from(rootProject.file("app/src/main/java/app/orchard/tv/ui/theme/GlyphPaths.kt"))
    from(rootProject.file("app/src/main/java/app/orchard/tv/apps/TileRecipes.kt"))
    from(rootProject.file("app/src/main/java/app/orchard/tv/weather/Cities.kt"))
    from(rootProject.file("app/src/main/java/app/orchard/tv/apps/LayoutStore.kt"))
    from(rootProject.file("app/src/main/java/app/orchard/tv/apps/AppNames.kt"))
    from(rootProject.file("app/src/main/java/app/orchard/tv/apps/CustomIcons.kt"))
    from(rootProject.file("app/src/main/java/app/orchard/tv/wallpaper/ScreensaverVideos.kt"))
    from(rootProject.file("app/src/main/java/app/orchard/tv/wallpaper/LocalSaverSelection.kt"))
    from(rootProject.file("app/src/main/java/app/orchard/tv/wallpaper/BoxBlur.kt"))
    from(rootProject.file("app/src/main/java/app/orchard/tv/wallpaper/ImageSampling.kt"))
    from(rootProject.file("app/src/main/java/app/orchard/tv/wallpaper/AtomicFileWrite.kt"))
    from(rootProject.file("app/src/main/java/app/orchard/tv/system/MitvPanel.kt"))
    from(rootProject.file("app/src/main/java/app/orchard/tv/system/DeviceProfile.kt"))
    from(rootProject.file("app/src/main/java/app/orchard/tv/system/OutputDevice.kt"))
    into(sharedSources.map { it.dir("app/orchard/tv/lite") })
    // Into Lite's package; Compose's state and AndroidX's prefs.edit {} come from Lite's Shims.kt.
    filter { line ->
        when {
            line.startsWith("import androidx.compose.runtime.") || line == "import androidx.core.content.edit" -> ""
            line.startsWith("import app.orchard.tv.") -> ""
            else -> line.replace(Regex("^package app\\.orchard\\.tv(\\.[a-z.]+)?$"), "package app.orchard.tv.lite")
                .replace("app.orchard.tv.ui.theme.Glyph", "app.orchard.tv.lite.Glyph")
                .replace("TileArtFactory.W", "TileFactory.W")
                .replace("URL(address).openConnection() as HttpURLConnection", "Net.open(address)")
                .replace("c.contentLengthLong", "c.contentLength.toLong()")
                .replace("app.orchard.tv.system.CompatibleHttp.open(address)", "Net.open(address)")
                .replace("app.orchard.tv.system.CompatibleHttp.open(url)", "Net.open(url)")
                .replace("app.orchard.tv.system.CompatibleHttp.init(context)", "Net.init(context)")
        }
    }
}
android.sourceSets["main"].java.srcDir(sharedSources)
// The full app's wording in all five languages, so menus and Control Center say the same thing.
val sharedRes = layout.buildDirectory.dir("generated/sharedRes")
val copyStrings by tasks.registering(Copy::class) {
    from(rootProject.file("app/src/main/res")) {
        include("values*/strings.xml", "values*/halo_update_media.xml", "values*/halo_announcements.xml", "values*/halo_migration.xml")
        rename("strings.xml", "app_strings.xml")
    }
    into(sharedRes)
    // Lite keeps its own name.
    filter { line -> if (line.contains("name=\"app_name\"") || line.contains("name=\"aerial_library")) "" else line }
}
android.sourceSets["main"].res.srcDir(sharedRes)
tasks.named("preBuild") { dependsOn(copyLiteAssets, copySources, copyStrings) }

dependencies {
    // The phone page's server and its QR code. ZXing 3.3.0, the last before it used
    // StandardCharsets, which Android only has from 4.4.
    implementation("org.nanohttpd:nanohttpd:2.3.1")
    implementation("com.google.zxing:core:3.3.0")
    testImplementation("junit:junit:4.13.2")
    testImplementation("org.robolectric:robolectric:4.17")
}

// `./gradlew :lite:assembleRelease -Pnohome`: a build for trying Lite on a TV that runs the full
// app, as a plain app from Aerial's grid. Without the HOME declaration it leaves the TV's choice
// of Home alone (a new Home candidate can reset it).
if (project.hasProperty("nohome")) {
    val noHomeManifest = layout.buildDirectory.file("generated/nohome/AndroidManifest.xml")
    val stripHome by tasks.registering {
        val src = file("src/main/AndroidManifest.xml")
        inputs.file(src)
        outputs.file(noHomeManifest)
        doLast {
            val text = src.readText().replace(
                Regex("""\s*<intent-filter>\s*<action android:name="android.intent.action.MAIN" />\s*<category android:name="android.intent.category.HOME" />.*?</intent-filter>""", RegexOption.DOT_MATCHES_ALL),
                "",
            )
            check(!text.contains("category.HOME")) { "the HOME filter is still there" }
            noHomeManifest.get().asFile.apply { parentFile.mkdirs() }.writeText(text)
        }
    }
    android.sourceSets["main"].manifest.srcFile(noHomeManifest)
    tasks.named("preBuild") { dependsOn(stripHome) }
}
