# HaloTV 3.1 源码

HaloTV 基于 [Aerial](https://github.com/pengchujin/aerial-tv) 二次开发，保留原作者版权与 MIT 许可。发行、下载和完整说明见 [HaloTV 仓库](https://github.com/Null9797/halo-tv)。

本源码构建六个版本：过渡版和独立版分别提供 Standard、Guard、Lite。正式版最低 Android 5.0；Lite 最低 Android 4.0，采用轻量 Views 实现。迁移细节见 [MIGRATION-GUIDE.md](MIGRATION-GUIDE.md)。

## 构建

使用 JDK 17、Android SDK 36。配置本机 `local.properties` 的 SDK 路径。签名文件不随源码发布；在私有 `local/signing.properties`（过渡版）或 `local/independent-signing.properties`（独立版）配置 `storeFile`、`storePassword`、`keyAlias`、`keyPassword`。

过渡版：
```
./gradlew :app:assembleStandardRelease :app:assembleGuardRelease :lite:assembleRelease
```

独立版：
```
./gradlew :app:assembleStandardRelease :app:assembleGuardRelease :lite:assembleRelease -PhaloIndependent
```

自行二次构建请使用自己的签名，并相应调整 BuildConfig 证书指纹和测试公钥夹具；自己的证书不能覆盖维护者的正式发布包。新包名不继承 Android 系统权限，迁移只提供经过身份验证的设置和素材导入。

运行测试时建议 `--max-workers=1`，避免多个 flavor 的本地服务测试争用端口。
